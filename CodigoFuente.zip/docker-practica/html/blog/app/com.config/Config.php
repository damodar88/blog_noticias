<?php

  define('DB_HOST','localhost');

  define('DB_USUARIO','root');

  define('DB_PASSWORD','pass');

  define('DB_NOMBRE','mydb');

  define('DB_CHARSET','UTF8');

?>
