<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Ciudad
 *
 * @author damodar
 */
class Ciudad {

    private $idCiudad;
    private $nombreCiudad;
    private $localidadCiudad;
    
    public function __construct($idCiudad, $nombreCiudad, $localidadCiudad) {
        $this->idCiudad = $idCiudad;
        $this->nombreCiudad = $nombreCiudad;
        $this->localidadCiudad = $localidadCiudad;
    }


    public function getIdCiudad() {
        return $this->idCiudad;
    }

    public function getNombreCiudad() {
        return $this->nombreCiudad;
    }

    public function getLocalidadCiudad() {
        return $this->localidadCiudad;
    }

    public function setIdCiudad($idCiudad) {
        $this->idCiudad = $idCiudad;
    }

    public function setNombreCiudad($nombreCiudad) {
        $this->nombreCiudad = $nombreCiudad;
    }

    public function setLocalidadCiudad($localidadCiudad) {
        $this->localidadCiudad = $localidadCiudad;
    }




//put your code here
    
}
